"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { useRouter } from "next/navigation"
import Image from "next/image"

interface Position {
  x: number;
  y: number;
}

interface Formation {
  name: string;
  positions: Record<string, Position[]>;
}

const formations: Record<string, Formation> = {
  "4-4-2": {
    name: "4-4-2",
    positions: {
      POR: [{ x: 50, y: 90 }],
      DEF: [{ x: 20, y: 70 }, { x: 40, y: 70 }, { x: 60, y: 70 }, { x: 80, y: 70 }],
      MED: [{ x: 20, y: 45 }, { x: 40, y: 45 }, { x: 60, y: 45 }, { x: 80, y: 45 }],
      DEL: [{ x: 40, y: 20 }, { x: 60, y: 20 }],
      ENT: [{ x: 5, y: 50 }]
    }
  },
  "4-3-3": {
    name: "4-3-3",
    positions: {
      POR: [{ x: 50, y: 90 }],
      DEF: [{ x: 20, y: 70 }, { x: 40, y: 70 }, { x: 60, y: 70 }, { x: 80, y: 70 }],
      MED: [{ x: 30, y: 50 }, { x: 50, y: 50 }, { x: 70, y: 50 }],
      DEL: [{ x: 30, y: 20 }, { x: 50, y: 20 }, { x: 70, y: 20 }],
      ENT: [{ x: 5, y: 50 }]
    }
  },
  "4-1-4-1": {
    name: "4-1-4-1",
    positions: {
      POR: [{ x: 50, y: 90 }],
      DEF: [{ x: 20, y: 70 }, { x: 40, y: 70 }, { x: 60, y: 70 }, { x: 80, y: 70 }],
      MED: [{ x: 50, y: 55 }, { x: 20, y: 40 }, { x: 40, y: 40 }, { x: 60, y: 40 }, { x: 80, y: 40 }],
      DEL: [{ x: 50, y: 20 }],
      ENT: [{ x: 5, y: 50 }]
    }
  },
  "5-4-1": {
    name: "5-4-1",
    positions: {
      POR: [{ x: 50, y: 90 }],
      DEF: [{ x: 15, y: 70 }, { x: 30, y: 70 }, { x: 50, y: 70 }, { x: 70, y: 70 }, { x: 85, y: 70 }],
      MED: [{ x: 25, y: 45 }, { x: 45, y: 45 }, { x: 55, y: 45 }, { x: 75, y: 45 }],
      DEL: [{ x: 50, y: 20 }],
      ENT: [{ x: 5, y: 50 }]
    }
  }
}

const futsalFormations: Record<string, Formation> = {
  "1-2-1": {
    name: "1-2-1 (Sala)",
    positions: {
      POR: [{ x: 50, y: 85 }],
      CIE: [{ x: 50, y: 65 }],
      ALA: [{ x: 30, y: 45 }, { x: 70, y: 45 }],
      PIV: [{ x: 50, y: 25 }],
      ENT: [{ x: 5, y: 50 }]
    }
  },
  "1-1-2": {
    name: "1-1-2 (Sala)",
    positions: {
      POR: [{ x: 50, y: 85 }],
      CIE: [{ x: 50, y: 55 }],
      ALA: [{ x: 35, y: 35 }, { x: 65, y: 35 }],
      PIV: [{ x: 50, y: 15 }],
      ENT: [{ x: 5, y: 50 }]
    }
  }
}

export default function AlineacionPage() {
  const [user, setUser] = useState<any>(null)
  const [selectedFormation, setSelectedFormation] = useState("4-4-2")
  const [isFutsal, setIsFutsal] = useState(false)
  const [lineup, setLineup] = useState<any>({})
  const [deadline, setDeadline] = useState<Date>(new Date())
  const [isMobile, setIsMobile] = useState(false)
  const [jornadaId, setJornadaId] = useState<string>("")
  const [locked, setLocked] = useState<boolean>(false)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("fantasyaragon_user")
    if (!userData) {
      router.push("/login")
      return
    }
    const parsed = JSON.parse(userData)
    setUser(parsed)

    // Calcular deadline (próximo viernes a las 21:00)
    const now = new Date()
    const nextFriday = new Date()
    nextFriday.setDate(now.getDate() + (5 - now.getDay() + 7) % 7)
    nextFriday.setHours(21, 0, 0, 0)
    if (nextFriday <= now) {
      nextFriday.setDate(nextFriday.getDate() + 7)
    }
    setDeadline(nextFriday)

    const jid = `${nextFriday.getFullYear()}-${String(nextFriday.getMonth() + 1).padStart(2, '0')}-${String(nextFriday.getDate()).padStart(2, '0')}`
    setJornadaId(jid)
    setLocked(now.getTime() > nextFriday.getTime())

    // Cargar alineación guardada para esta jornada, si existe
    const userLineups = parsed?.lineups && !Array.isArray(parsed.lineups) ? parsed.lineups : {}
    const savedForJornada = userLineups?.[jid]
    if (savedForJornada) {
      setSelectedFormation(savedForJornada.formation || selectedFormation)
      setIsFutsal(savedForJornada.isFutsal ?? isFutsal)
      setLineup(savedForJornada.players || {})
    }

    // Detectar móvil
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [router])

  const getAvailableFormations = (): Record<string, Formation> => {
    return isFutsal ? futsalFormations : formations
  }

  const getPlayersByPosition = (position: string) => {
    if (!user?.players) return []

    if (isFutsal) {
      const futsalPositions = ["POR", "CIE", "ALA", "PIV", "ENT"]
      if (!futsalPositions.includes(position)) return []

      return user.players.filter((player: any) => {
        if (position === "POR" && player.position === "POR") return true
        if (position === "CIE" && player.position === "CIE") return true
        if (position === "ALA" && player.position === "ALA") return true
        if (position === "PIV" && player.position === "PIV") return true
        if (position === "ENT" && player.position === "ENT") return true
        return false
      })
    } else {
      const footballPositions = ["POR", "DEF", "MED", "DEL", "ENT"]
      if (!footballPositions.includes(position)) return []

      return user.players.filter((player: any) => {
        if (position === "POR" && player.position === "POR" && player.category === "Fútbol 11") return true
        if (position === "DEF" && player.position === "DEF") return true
        if (position === "MED" && player.position === "MED") return true
        if (position === "DEL" && player.position === "DEL") return true
        if (position === "ENT" && player.position === "ENT") return true
        return false
      })
    }
  }

  // Helper to avoid duplicate player assignments across positions
  const isPlayerUsed = (playerId: number) => {
    return Object.values(lineup).some((p: any) => p?.id === playerId)
  }

  const assignPlayer = (position: string, positionIndex: number, player: any) => {
    if (locked) return
    if (isPlayerUsed(player.id)) {
      alert("Este jugador ya está asignado en otra posición")
      return
    }
    const key = `${position}_${positionIndex}`
    setLineup({
      ...lineup,
      [key]: player
    })
  }

  const removePlayer = (position: string, positionIndex: number) => {
    if (locked) return
    const key = `${position}_${positionIndex}`
    const newLineup = { ...lineup }
    delete newLineup[key]
    setLineup(newLineup)
  }

  // Scoring weights by position (different for fútbol 11 vs sala)
  const getPositionWeight = (pos: string) => {
    if (isFutsal) {
      const weights: Record<string, number> = { POR: 1.1, CIE: 1.05, ALA: 1.1, PIV: 1.2, ENT: 0.5 }
      return weights[pos] ?? 1
    }
    const weights: Record<string, number> = { POR: 1.1, DEF: 1.05, MED: 1.0, DEL: 1.2, ENT: 0.5 }
    return weights[pos] ?? 1
  }

  const computeScore = () => {
    // Sum base points applying position weights
    let total = 0
    for (const [key, p] of Object.entries(lineup)) {
      const pos = key.split('_')[0]
      const base = (p as any)?.points || 0
      const weight = getPositionWeight(pos)
      total += Math.round(base * weight)
    }
    return total
  }

  const saveLineup = () => {
    if (locked) {
      alert("La jornada está cerrada. No puedes guardar cambios.")
      return
    }
    const score = computeScore()

    const prevLineups = user?.lineups && !Array.isArray(user.lineups) ? user.lineups : {}
    const updatedUser = {
      ...user,
      lineups: {
        ...prevLineups,
        [jornadaId]: {
          formation: selectedFormation,
          isFutsal,
          players: lineup,
          savedAt: new Date().toISOString(),
          score,
        },
      },
      currentLineup: {
        formation: selectedFormation,
        isFutsal,
        players: lineup,
        savedAt: new Date().toISOString(),
      },
    }
    setUser(updatedUser)
    localStorage.setItem("fantasyaragon_user", JSON.stringify(updatedUser))

    try {
      const leagueRaw = localStorage.getItem("fantasyaragon_league")
      const league = leagueRaw ? JSON.parse(leagueRaw) : { users: [] }
      const idx = league.users.findIndex((u: any) => u.id === user.id)
      if (idx === -1) {
        league.users.push({ id: user.id, email: user.email, lineups: { [jornadaId]: updatedUser.lineups[jornadaId] } })
      } else {
        league.users[idx].email = user.email
        league.users[idx].lineups = {
          ...(league.users[idx].lineups || {}),
          [jornadaId]: updatedUser.lineups[jornadaId],
        }
      }
      localStorage.setItem("fantasyaragon_league", JSON.stringify(league))
    } catch {}

    alert("Alineación guardada correctamente para la jornada " + jornadaId + ` (Puntos: ${score})`)
  }

  const getTimeUntilDeadline = () => {
    const now = new Date()
    const diff = deadline.getTime() - now.getTime()
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

    if (days > 0) return `${days}d ${hours}h ${minutes}m`
    if (hours > 0) return `${hours}h ${minutes}m`
    return `${minutes}m`
  }

  if (!user) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="text-center">
        <div className="w-16 h-16 mx-auto mb-4 rounded-full overflow-hidden bg-white shadow-lg">
          <Image
            src="/atletico-aragon-logo.svg"
            alt="Atlético Aragón Logo"
            width={64}
            height={64}
            className="w-full h-full object-contain p-2"
          />
        </div>
        <p>Cargando...</p>
      </div>
    </div>
  }

  const currentFormations = getAvailableFormations()
  const currentFormation = currentFormations[selectedFormation]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-10 h-10 rounded-full overflow-hidden">
                  <Image
                    src="https://ugc.same-assets.com/_IW6EEni8tywghjK3gTRXGPjrfl6NMKV.png"
                    alt="Atlético Aragón Logo"
                    width={40}
                    height={40}
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="hidden sm:block">
                  <h1 className="text-xl font-bold text-gray-900">FantasyAragon</h1>
                  <p className="text-xs text-gray-600">Alineación</p>
                </div>
              </Link>
            </div>

            {/* Navigation for desktop */}
            <nav className="hidden md:flex space-x-8">
              <Link href="/mercado" className="text-gray-700 hover:text-aragon-red transition-colors">
                Mercado
              </Link>
              <Link href="/alineacion" className="text-aragon-red font-medium">
                Alineación
              </Link>
              <Link href="/mi-equipo" className="text-gray-700 hover:text-aragon-red transition-colors">
                Mi Equipo
              </Link>
            </nav>

            <div className="flex items-center space-x-2">
              <div className="text-right hidden sm:block">
                <p className="text-sm text-red-600 font-medium">Cierre: {getTimeUntilDeadline()}</p>
                <p className="text-xs text-gray-500">Viernes 21:00</p>
              </div>
              <div className="w-8 h-8 bg-aragon-gradient rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xs">{user.email[0].toUpperCase()}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      <div className="md:hidden bg-white border-b">
        <div className="flex justify-around py-2">
          <Link href="/mercado" className="text-gray-700 text-sm py-2 px-4">
            Mercado
          </Link>
          <Link href="/alineacion" className="text-aragon-red font-medium text-sm py-2 px-4 border-b-2 border-aragon-red">
            Alineación
          </Link>
          <Link href="/mi-equipo" className="text-gray-700 text-sm py-2 px-4">
            Mi Equipo
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <div className="mb-3 p-3 rounded border bg-white flex flex-wrap items-center gap-3">
          <span className="text-sm text-gray-600">Jornada:</span>
          <span className="text-sm font-semibold">{jornadaId || "-"}</span>
          <span className={`text-xs px-2 py-1 rounded ${locked ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
            {locked ? 'Cerrada (después de Viernes 21:00)' : 'Abierta'}
          </span>
        </div>
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2 bg-[#ffffff]">Configurar Alineación</h1>
          <p className="text-gray-600 text-sm sm:text-base">Elige tu formación y posiciona a tus jugadores del Atlético Aragón</p>
          <div className="mt-2 sm:hidden">
            <p className="text-sm text-red-600 font-medium">Cierre en: {getTimeUntilDeadline()}</p>
          </div>
        </div>

        <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-1 lg:grid-cols-3'} gap-6 sm:gap-8`}>
          {/* Configuración */}
          <div className={`${isMobile ? 'order-2' : 'order-1'} space-y-4 sm:space-y-6`}>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg sm:text-xl">Tipo de Equipo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-4">
                  <Button
                    variant={!isFutsal ? "default" : "outline"}
                    onClick={() => {
                      setIsFutsal(false)
                      setSelectedFormation("4-4-2")
                      setLineup({})
                    }}
                    className="flex-1 text-sm"
                  >
                    Fútbol 11
                  </Button>
                  <Button
                    variant={isFutsal ? "default" : "outline"}
                    onClick={() => {
                      setIsFutsal(true)
                      setSelectedFormation("1-2-1")
                      setLineup({})
                    }}
                    className="flex-1 text-sm"
                  >
                    Fútbol Sala
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg sm:text-xl">Formación</CardTitle>
              </CardHeader>
              <CardContent>
                <select
                  value={selectedFormation}
                  onChange={(e) => setSelectedFormation(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-aragon-blue text-sm"
                >
                  {Object.keys(currentFormations).map((formation) => (
                    <option key={formation} value={formation}>
                      {currentFormations[formation].name}
                    </option>
                  ))}
                </select>
              </CardContent>
            </Card>

            {/* Lista de jugadores disponibles - Colapsible en móvil */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg sm:text-xl">Jugadores Disponibles</CardTitle>
              </CardHeader>
              <CardContent className={`${isMobile ? 'max-h-60' : 'max-h-96'} overflow-y-auto`}>
                {Object.keys(currentFormation.positions).map((position) => {
                  const availablePlayers = getPlayersByPosition(position)
                  if (availablePlayers.length === 0) return null

                  return (
                    <div key={position} className="mb-4">
                      <h4 className="font-medium text-gray-900 mb-2 text-sm">{position}</h4>
                      <div className="space-y-2">
                        {availablePlayers.map((player: any) => (
                          <div
                            key={player.id}
                            className="flex items-center justify-between p-2 bg-gray-50 rounded cursor-pointer hover:bg-gray-100"
                          >
                            <div className="flex items-center space-x-2">
                              <Image
                                src={player.photo || "https://ugc.same-assets.com/AOraU0yE9LJyMpKlwGCyvhGp6QowQNRU.png"}
                                alt={player.name}
                                width={32}
                                height={32}
                                className="rounded-full border border-gray-300"
                              />
                              <div>
                                <p className="font-medium text-xs sm:text-sm">{player.name}</p>
                                <p className="text-xs text-gray-600">{player.category}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-xs sm:text-sm font-medium">{player.points} pts</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )
                })}
              </CardContent>
            </Card>
          </div>

          {/* Campo de juego */}
          <div className={`${isMobile ? 'order-1 lg:col-span-2' : 'order-2 lg:col-span-2'}`}>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg sm:text-xl">Campo - {currentFormation.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className={`relative rounded-lg mx-auto border-2 ${isFutsal ? 'bg-blue-100 border-blue-200' : 'bg-green-100 border-green-200'}`}
                  style={{
                    height: isMobile ? "400px" : "600px",
                    maxWidth: isMobile ? "100%" : "600px"
                  }}
                >
                  {/* Líneas del campo */}
                  <div className="absolute inset-0">
                    <div className={`absolute top-0 left-1/2 transform -translate-x-1/2 w-16 sm:w-24 h-10 sm:h-16 border-2 border-white ${isFutsal ? 'bg-blue-200' : 'bg-green-200'}`}></div>
                    <div className={`absolute bottom-0 left-1/2 transform -translate-x-1/2 w-16 sm:w-24 h-10 sm:h-16 border-2 border-white ${isFutsal ? 'bg-blue-200' : 'bg-green-200'}`}></div>
                    <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-white"></div>
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-16 sm:w-20 h-16 sm:h-20 border-2 border-white rounded-full"></div>
                  </div>

                  {/* Posiciones de jugadores */}
                  {Object.entries(currentFormation.positions).map(([position, positions]) =>
                    positions.map((pos: Position, index: number) => {
                      const key = `${position}_${index}`
                      const assignedPlayer = lineup[key]
                      const size = isMobile ? 12 : 16; // Tamaño más pequeño en móvil

                      return (
                        <div
                          key={key}
                          className="absolute transform -translate-x-1/2 -translate-y-1/2"
                          style={{
                            left: `${pos.x}%`,
                            top: `${pos.y}%`,
                            width: `${size * 4}px`,
                            height: `${size * 4}px`
                          }}
                        >
                          {assignedPlayer ? (
                            <div
                              className="relative group cursor-pointer"
                              onClick={() => removePlayer(position, index)}
                            >
                              <Image
                                src={assignedPlayer.photo || "https://ugc.same-assets.com/4D-bbzYcnFwtG3saM6AiTIJ9ia-93mjH.png"}
                                alt={assignedPlayer.name}
                                width={56}
                                height={56}
                                className="rounded-full border-4 border-white shadow-lg hover:border-aragon-red transition-all"
                              />
                              <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 bg-white px-2 py-0.5 rounded text-xs font-bold whitespace-nowrap shadow">
                                {assignedPlayer.name.split(' ')[0]}
                              </div>
                              <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-black text-white px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                Click para quitar
                              </div>
                            </div>
                          ) : (
                            <div className="w-full h-full bg-gray-300 rounded-full flex items-center justify-center text-gray-600 font-bold border-2 border-dashed border-gray-400">
                              <select
                                disabled={locked}
                                onChange={(e) => {
                                  const playerId = parseInt(e.target.value)
                                  if (!playerId) return
                                  if (isPlayerUsed(playerId)) {
                                    alert("Este jugador ya está asignado en otra posición")
                                    return
                                  }
                                  const player = user.players.find((p: any) => p.id === playerId)
                                  if (player) assignPlayer(position, index, player)
                                }}
                                className="w-full h-full rounded-full bg-transparent border-none outline-none cursor-pointer text-center"
                                style={{ fontSize: isMobile ? '10px' : '12px' }}
                              >
                                <option value="">{position}</option>
                                {getPlayersByPosition(position)
                                  .filter((p: any) => !isPlayerUsed(p.id))
                                  .map((player: any) => (
                                    <option key={player.id} value={player.id}>
                                      {player.name.split(' ')[0]}
                                    </option>
                                  ))}
                              </select>
                            </div>
                          )}
                        </div>
                      )
                    })
                  )}
                </div>
              </CardContent>
            </Card>

            <div className="mt-4 sm:mt-6 flex flex-col sm:flex-row justify-between gap-4">
              <Button
                variant="outline"
                onClick={() => setLineup({})}
                className="w-full sm:w-auto"
              >
                Limpiar Alineación
              </Button>
              <Button
                onClick={saveLineup}
                className="bg-aragon-red hover:bg-red-700 w-full sm:w-auto"
                disabled={locked || Object.keys(lineup).length === 0}
              >
                {locked ? 'Bloqueado' : 'Guardar Alineación'}
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
