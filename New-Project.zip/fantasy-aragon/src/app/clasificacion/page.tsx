"use client"

import { useEffect, useMemo, useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface LeagueUserLineup {
  formation: string
  isFutsal?: boolean
  players: Record<string, any>
  savedAt?: string
  score?: number
}

interface LeagueUser {
  id: string
  email: string
  lineups: Record<string, LeagueUserLineup>
}

export default function ClasificacionPage() {
  const [league, setLeague] = useState<{ users: LeagueUser[] }>({ users: [] })
  const [currentUser, setCurrentUser] = useState<any>(null)
  const [selectedJornada, setSelectedJornada] = useState<string>("")
  const [openUserId, setOpenUserId] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Cargar usuario y liga desde localStorage
    try {
      const userRaw = localStorage.getItem("fantasyaragon_user")
      if (!userRaw) {
        router.push("/login")
        return
      }
      const user = JSON.parse(userRaw)
      setCurrentUser(user)

      const leagueRaw = localStorage.getItem("fantasyaragon_league")
      const parsedLeague = leagueRaw ? JSON.parse(leagueRaw) : { users: [] }
      setLeague(parsedLeague)

      // Detectar jornadas disponibles y seleccionar la más reciente
      const jornadas = new Set<string>()
      parsedLeague.users?.forEach((u: LeagueUser) => {
        Object.keys(u.lineups || {}).forEach((jid) => jornadas.add(jid))
      })
      const sorted = Array.from(jornadas).sort()
      if (sorted.length > 0) setSelectedJornada(sorted[sorted.length - 1])
    } catch {}
  }, [router])

  const ranking = useMemo(() => {
    if (!selectedJornada) return []
    const rows = (league.users || []).map((u) => {
      const lineup = (u.lineups || {})[selectedJornada]
      return {
        id: u.id,
        email: u.email,
        score: lineup?.score ?? 0,
        lineup,
      }
    })
    rows.sort((a, b) => (b.score || 0) - (a.score || 0))
    return rows
  }, [league, selectedJornada])

  const jornadasDisponibles = useMemo(() => {
    const jornadas = new Set<string>()
    ;(league.users || []).forEach((u) => {
      Object.keys(u.lineups || {}).forEach((jid) => jornadas.add(jid))
    })
    return Array.from(jornadas).sort()
  }, [league])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 rounded-full overflow-hidden">
                <Image
                  src="https://ugc.same-assets.com/zfPt_lniKW18Dktg8C9oqlVAau7lxFDd.png"
                  alt="Atlético Aragón Logo"
                  width={40}
                  height={40}
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-xl font-bold text-gray-900">FantasyAragon</h1>
                <p className="text-xs text-gray-600">Clasificación</p>
              </div>
            </Link>

            <nav className="hidden md:flex space-x-6">
              <Link href="/mercado" className="text-gray-700 hover:text-aragon-red">Mercado</Link>
              <Link href="/alineacion" className="text-gray-700 hover:text-aragon-red">Alineación</Link>
              <Link href="/mi-equipo" className="text-gray-700 hover:text-aragon-red">Mi Equipo</Link>
              <Link href="/clasificacion" className="text-aragon-red font-medium">Clasificación</Link>
            </nav>

            {currentUser && (
              <div className="w-9 h-9 bg-aragon-gradient rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xs">{currentUser.email[0].toUpperCase()}</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      <div className="md:hidden bg-white border-b">
        <div className="flex justify-around py-2 text-sm">
          <Link href="/mercado" className="text-gray-700 py-2 px-2">🛒 Mercado</Link>
          <Link href="/alineacion" className="text-gray-700 py-2 px-2">⚽ Alineación</Link>
          <Link href="/clasificacion" className="text-aragon-red font-medium py-2 px-2 border-b-2 border-aragon-red">🏆 Clasificación</Link>
          <Link href="/mi-equipo" className="text-gray-700 py-2 px-2">👥 Equipo</Link>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">Clasificación</h2>
            <p className="text-gray-600 text-sm">Consulta el ranking por jornada y las alineaciones de cada usuario</p>
          </div>
          <div className="flex items-center gap-2">
            <label className="text-sm text-gray-700">Jornada</label>
            <select
              className="px-3 py-2 border border-gray-300 rounded-md text-sm"
              value={selectedJornada}
              onChange={(e) => setSelectedJornada(e.target.value)}
            >
              {jornadasDisponibles.length === 0 && (
                <option value="">Sin jornadas</option>
              )}
              {jornadasDisponibles.map((jid) => (
                <option key={jid} value={jid}>{jid}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Tabla de clasificación */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Ranking - {selectedJornada || "—"}</CardTitle>
          </CardHeader>
          <CardContent>
            {ranking.length === 0 ? (
              <p className="text-gray-600 text-sm">Aún no hay alineaciones guardadas para esta jornada.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="text-left text-gray-600 border-b">
                      <th className="py-2 pr-3">Pos</th>
                      <th className="py-2 pr-3">Usuario</th>
                      <th className="py-2 pr-3">Puntos</th>
                      <th className="py-2 pr-3">Alineación</th>
                    </tr>
                  </thead>
                  <tbody>
                    {ranking.map((row, idx) => (
                      <tr key={row.id} className={`border-b ${currentUser?.id === row.id ? 'bg-blue-50' : ''}`}>
                        <td className="py-3 pr-3 font-medium">{idx + 1}</td>
                        <td className="py-3 pr-3">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-aragon-gradient rounded-full flex items-center justify-center text-white text-xs font-bold">
                              {row.email?.[0]?.toUpperCase()}
                            </div>
                            <div className="truncate max-w-[220px]">
                              <p className="font-medium truncate">{row.email}</p>
                              <p className="text-xs text-gray-500 truncate">{row.lineup?.isFutsal ? 'Fútbol Sala' : 'Fútbol 11'} · {row.lineup?.formation || '-'}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 pr-3 font-semibold">{row.score}</td>
                        <td className="py-3 pr-3">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setOpenUserId(openUserId === row.id ? null : row.id)}
                          >
                            {openUserId === row.id ? 'Ocultar' : 'Ver alineación'}
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Alineación expandida */}
        {ranking.map((row) => (
          openUserId === row.id && row.lineup && (
            <Card key={`open-${row.id}`} className="mt-6">
              <CardHeader>
                <CardTitle className="text-base">Alineación de {row.email} · {row.lineup.isFutsal ? 'Fútbol Sala' : 'Fútbol 11'} · {row.lineup.formation}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {Object.entries(row.lineup.players || {}).map(([spot, p]: any) => (
                    <div key={spot} className="flex flex-col items-center">
                      <Image
                        src={p.photo || "https://api.dicebear.com/7.x/avataaars/svg?seed=default"}
                        alt={p.name}
                        width={56}
                        height={56}
                        className="rounded-full border-2 border-white shadow"
                      />
                      <p className="mt-2 text-xs text-center font-medium leading-tight">
                        {p.name}
                      </p>
                      <p className="text-[10px] text-gray-500">{p.position}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )
        ))}

        {/* Acciones rápidas */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="border-2 border-aragon-blue">
            <CardHeader>
              <CardTitle className="text-aragon-blue">Ir al Mercado</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-3">Fíchate a los mejores para la próxima jornada.</p>
              <Link href="/mercado">
                <Button>Mercado</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="border-2 border-aragon-red">
            <CardHeader>
              <CardTitle className="text-aragon-red">Crear Alineación</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-3">Configura tu once antes del viernes a las 21:00.</p>
              <Link href="/alineacion">
                <Button className="bg-aragon-red hover:bg-red-700">Alineación</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
