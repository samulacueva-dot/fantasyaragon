"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { useRouter } from "next/navigation"
import Image from "next/image"

export default function RegisterPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (password !== confirmPassword) {
      setError("Las contraseñas no coinciden")
      return
    }

    if (password.length < 6) {
      setError("La contraseña debe tener al menos 6 caracteres")
      return
    }

    setLoading(true)

    // Simular registro - aquí conectarías con tu backend
    setTimeout(() => {
      // Guardar usuario en localStorage por ahora
      const user = {
        email,
        id: Math.random().toString(36).substr(2, 9),
        budget: 100000000, // 100M€
        players: [],
        lineups: []
      }
      localStorage.setItem("fantasyaragon_user", JSON.stringify(user))
      router.push("/mercado")
    }, 1500)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header simplificado */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 rounded-full overflow-hidden">
                <Image
                  src="https://ugc.same-assets.com/AuzgjSeM_WXlv9td4TUtC4lBCEhnrgoo.png"
                  alt="Atlético Aragón Logo"
                  width={40}
                  height={40}
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">FantasyAragon</h1>
                <p className="text-xs text-gray-600">Atlético Aragón Fantasy</p>
              </div>
            </Link>

            <Link href="/login">
              <Button variant="outline" size="sm">
                ¿Ya tienes cuenta?
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Formulario de registro */}
      <main className="max-w-md mx-auto px-4 py-16">
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full overflow-hidden bg-white shadow-lg">
              <Image
                src="https://ugc.same-assets.com/BAoSG8PNwPKG975SP8s-9r4GUQyMZMW7.png"
                alt="Atlético Aragón Logo"
                width={64}
                height={64}
                className="w-full h-full object-contain p-2"
              />
            </div>
            <CardTitle className="text-2xl text-gray-900">Únete a FantasyAragon</CardTitle>
            <p className="text-gray-600 mt-2">
              Crea tu cuenta y empieza a gestionar tu equipo del Atlético Aragón
            </p>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Correo electrónico
                </label>
                <input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-aragon-blue focus:border-transparent"
                  placeholder="tu@email.com"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Contraseña
                </label>
                <input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-aragon-blue focus:border-transparent"
                  placeholder="Mínimo 6 caracteres"
                />
              </div>

              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                  Confirmar contraseña
                </label>
                <input
                  id="confirmPassword"
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-aragon-blue focus:border-transparent"
                  placeholder="Repite tu contraseña"
                />
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md text-sm">
                  {error}
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-md text-sm">
                <p className="font-medium">🎁 Bono de bienvenida:</p>
                <p>Recibirás 100.000.000€ para empezar a fichar jugadores</p>
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-aragon-red hover:bg-red-700 text-white py-2 h-11"
              >
                {loading ? "Creando cuenta..." : "Crear mi cuenta"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                ¿Ya tienes una cuenta?{" "}
                <Link href="/login" className="text-aragon-blue hover:text-blue-700 font-medium">
                  Inicia sesión aquí
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 text-center text-sm text-gray-500">
          <p>Al registrarte aceptas nuestros términos y condiciones</p>
        </div>
      </main>
    </div>
  )
}
