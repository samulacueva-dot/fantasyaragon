import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import ClientBody from './ClientBody'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'FantasyAragon - Fantasy Football del Atlético Aragón',
  description: 'Dirige tu propio equipo del Atlético Aragón y compite por conseguir la mejor puntuación en cada jornada.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <ClientBody className={inter.className}>
        {children}
      </ClientBody>
    </html>
  )
}
