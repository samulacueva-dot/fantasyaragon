import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"

export default function HomePage() {
  // Datos de ejemplo de la próxima jornada
  const nextMatches = [
    {
      homeTeam: "Atlético Aragón (Fútbol 11)",
      awayTeam: "Rival FC",
      date: "Sábado 14:30",
      status: "pending"
    },
    {
      homeTeam: "Atlético Aragón (Fútbol Sala)",
      awayTeam: "Villa FS",
      date: "Domingo 18:00",
      status: "pending"
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 rounded-full overflow-hidden">
                  <Image
                    src="https://ugc.same-assets.com/0eOVjsq1g6LyX12xMNrBH6TaoplTnIsn.png"
                    alt="Atlético Aragón Logo"
                    width={40}
                    height={40}
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">FantasyAragon</h1>
                  <p className="text-xs text-gray-600">Atlético Aragón Fantasy</p>
                </div>
              </div>
            </div>

            <nav className="hidden md:flex space-x-4 lg:space-x-8">
              <Link href="/mercado" className="text-gray-700 hover:text-aragon-red transition-colors text-sm lg:text-base">
                Mercado
              </Link>
              <Link href="/alineacion" className="text-gray-700 hover:text-aragon-red transition-colors text-sm lg:text-base">
                Alineación
              </Link>
              <Link href="/clasificacion" className="text-gray-700 hover:text-aragon-red transition-colors text-sm lg:text-base">
                Clasificación
              </Link>
              <Link href="/mi-equipo" className="text-gray-700 hover:text-aragon-red transition-colors text-sm lg:text-base">
                Mi Equipo
              </Link>
            </nav>

            <div className="flex items-center space-x-2 sm:space-x-4">
              <Link href="/login">
                <Button variant="outline" size="sm" className="text-xs sm:text-sm px-2 sm:px-3">
                  Iniciar
                </Button>
              </Link>
              <Link href="/register">
                <Button className="bg-aragon-red hover:bg-red-700 text-xs sm:text-sm px-2 sm:px-3" size="sm">
                  Registro
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      <div className="md:hidden bg-white border-b">
        <div className="flex justify-around py-3">
          <Link href="/mercado" className="text-gray-700 text-sm py-2 px-3 rounded hover:bg-gray-100">
            🛒 Mercado
          </Link>
          <Link href="/alineacion" className="text-gray-700 text-sm py-2 px-3 rounded hover:bg-gray-100">
            ⚽ Alineación
          </Link>
          <Link href="/mi-equipo" className="text-gray-700 text-sm py-2 px-3 rounded hover:bg-gray-100">
            👥 Mi Equipo
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="mb-6">
            <div className="w-24 h-24 mx-auto mb-4 rounded-full overflow-hidden bg-white shadow-lg">
              <Image
                src="https://ugc.same-assets.com/RfeaL9E_SQkAICEX74CDBPmhnmMAJiif.png"
                alt="Atlético Aragón Logo"
                width={96}
                height={96}
                className="w-full h-full object-contain p-2"
              />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4">
              Dirige tu equipo del
              <span className="text-aragon-blue block">Atlético Aragón</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Crea tu alineación ideal mezclando jugadores de fútbol 11 y fútbol sala.
              Compite cada jornada por conseguir la mayor puntuación con un presupuesto limitado.
            </p>
            <Link href="/register">
              <Button size="lg" className="bg-aragon-red hover:bg-red-700 text-white text-lg px-8 py-3">
                ¡Jugar Ahora!
              </Button>
            </Link>
          </div>
        </div>

        {/* Features Section */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <Card className="border-2 hover:border-aragon-blue transition-colors">
            <CardHeader>
              <CardTitle className="text-aragon-blue">💰 Mercado de Jugadores</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Ficha a los mejores jugadores del Atlético Aragón con tu presupuesto de 100M€.
                Los precios varían según el rendimiento.
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-aragon-blue transition-colors">
            <CardHeader>
              <CardTitle className="text-aragon-blue">⚽ Alineación Táctica</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Elige entre diferentes formaciones (4-4-2, 4-3-3, etc.) y mezcla jugadores
                de fútbol 11 y fútbol sala en tu once ideal.
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-aragon-blue transition-colors">
            <CardHeader>
              <CardTitle className="text-aragon-blue">🏆 Competición Semanal</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Cada jornada es una nueva oportunidad. Tienes hasta los viernes a las 21:00
                para configurar tu alineación.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Next Matches */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Próxima Jornada</h2>
          <div className="grid gap-4">
            {nextMatches.map((match, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full overflow-hidden bg-white shadow-md">
                        <Image
                          src="https://ugc.same-assets.com/2RUbWTDy5b6C9WgRIMkMnRIii-jU7vQN.png"
                          alt="Atlético Aragón Logo"
                          width={48}
                          height={48}
                          className="w-full h-full object-contain p-1"
                        />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{match.homeTeam}</h3>
                        <p className="text-sm text-gray-600">vs {match.awayTeam}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900">{match.date}</p>
                      <span className="inline-block px-2 py-1 text-xs bg-yellow-100 text-yellow-800 rounded">
                        Pendiente
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-aragon-gradient rounded-lg p-8 text-white">
          <h2 className="text-3xl font-bold mb-4">¿Listo para el desafío?</h2>
          <p className="text-xl mb-6">
            Únete a FantasyAragon y demuestra que sabes crear el mejor equipo
          </p>
          <Link href="/register">
            <Button size="lg" variant="secondary" className="bg-white text-aragon-blue hover:bg-gray-100">
              Crear Mi Equipo
            </Button>
          </Link>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-8 rounded-full overflow-hidden bg-white">
                <Image
                  src="https://ugc.same-assets.com/acJZ7Q7Vh-_e_YABmBw34jHNHkFzY6iW.png"
                  alt="Atlético Aragón Logo"
                  width={32}
                  height={32}
                  className="w-full h-full object-contain"
                />
              </div>
              <span className="text-xl font-bold">FantasyAragon</span>
            </div>
            <p className="text-gray-400">
              © 2025 FantasyAragon - Developer Samuel Lacueva
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
