"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { useRouter } from "next/navigation"
import Image from "next/image"

export default function MiEquipoPage() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("fantasyaragon_user")
    if (!userData) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(userData))
  }, [router])

  const sellPlayer = (playerId: number) => {
    if (!user) return

    const player = user.players.find((p: any) => p.id === playerId)
    if (!player) return

    // Vender por el 80% del precio original
    const sellPrice = Math.floor(player.price * 0.8)

    const updatedUser = {
      ...user,
      budget: user.budget + sellPrice,
      players: user.players.filter((p: any) => p.id !== playerId)
    }

    setUser(updatedUser)
    localStorage.setItem("fantasyaragon_user", JSON.stringify(updatedUser))
  }

  const formatPrice = (price: number) => {
    return `${(price / 1000000).toFixed(1)}M€`
  }

  const getFormColor = (form: string) => {
    switch (form) {
      case "excellent": return "text-green-600 bg-green-50"
      case "good": return "text-blue-600 bg-blue-50"
      case "average": return "text-yellow-600 bg-yellow-50"
      default: return "text-gray-600 bg-gray-50"
    }
  }

  const getPlayersByCategory = () => {
    if (!user?.players) return {}

    return user.players.reduce((acc: any, player: any) => {
      if (!acc[player.category]) {
        acc[player.category] = []
      }
      acc[player.category].push(player)
      return acc
    }, {})
  }

  const getTotalValue = () => {
    if (!user?.players) return 0
    return user.players.reduce((total: number, player: any) => total + player.price, 0)
  }

  if (!user) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 mx-auto mb-4 rounded-full overflow-hidden bg-white">
          <Image
            src="/atletico-aragon-logo.svg"
            alt="Atlético Aragón Logo"
            width={64}
            height={64}
            className="w-full h-full object-contain p-1"
          />
        </div>
        <p>Cargando...</p>
      </div>
    </div>
  }

  const playersByCategory = getPlayersByCategory()

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-10 h-10 rounded-full overflow-hidden bg-white">
                  <Image
                    src="/atletico-aragon-logo.svg"
                    alt="Atlético Aragón Logo"
                    width={40}
                    height={40}
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">FantasyAragon</h1>
                  <p className="text-xs text-gray-600">Mi Equipo</p>
                </div>
              </Link>
            </div>

            <nav className="hidden md:flex space-x-8">
              <Link href="/mercado" className="text-gray-700 hover:text-aragon-red transition-colors">
                Mercado
              </Link>
              <Link href="/alineacion" className="text-gray-700 hover:text-aragon-red transition-colors">
                Alineación
              </Link>
              <Link href="/mi-equipo" className="text-aragon-red font-medium">
                Mi Equipo
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-600">Presupuesto</p>
                <p className="font-bold text-aragon-blue">{formatPrice(user.budget)}</p>
              </div>
              <div className="w-10 h-10 bg-aragon-gradient rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">{user.email[0].toUpperCase()}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Mi Plantilla</h1>
          <p className="text-gray-600">Gestiona tus jugadores fichados del Atlético Aragón</p>
        </div>

        {/* Estadísticas del equipo */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-aragon-blue">Jugadores Fichados</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-gray-900">{user.players?.length || 0}</p>
              <p className="text-sm text-gray-600">Total en plantilla</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-aragon-blue">Valor Total</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-gray-900">{formatPrice(getTotalValue())}</p>
              <p className="text-sm text-gray-600">Precio de mercado</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-aragon-blue">Presupuesto Restante</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-aragon-red">{formatPrice(user.budget)}</p>
              <p className="text-sm text-gray-600">Disponible para fichajes</p>
            </CardContent>
          </Card>
        </div>

        {/* Lista de jugadores por categoría */}
        {Object.keys(playersByCategory).length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <div className="w-16 h-16 mx-auto mb-4 bg-gray-200 rounded-full flex items-center justify-center">
                <span className="text-2xl">⚽</span>
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">
                No tienes jugadores fichados
              </h3>
              <p className="text-gray-600 mb-6">
                Ve al mercado para empezar a fichar jugadores para tu equipo
              </p>
              <Link href="/mercado">
                <Button className="bg-aragon-red hover:bg-red-700">
                  Ir al Mercado
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-8">
            {Object.entries(playersByCategory).map(([category, players]) => (
              <div key={category}>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">{category}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {(players as any[]).map((player) => (
                    <Card key={player.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="text-lg">{player.name}</CardTitle>
                            <p className="text-sm text-gray-600">{player.category}</p>
                          </div>
                          <div className="text-center">
                            <span className="inline-block px-2 py-1 text-xs font-medium bg-aragon-blue text-white rounded">
                              {player.position}
                            </span>
                          </div>
                        </div>
                      </CardHeader>

                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Puntos</span>
                            <span className="font-bold text-gray-900">{player.points}</span>
                          </div>

                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Forma</span>
                            <span className={`px-2 py-1 text-xs font-medium rounded ${getFormColor(player.form)}`}>
                              {player.form === "excellent" ? "Excelente" :
                               player.form === "good" ? "Buena" : "Regular"}
                            </span>
                          </div>

                          <div className="border-t pt-3">
                            <div className="flex justify-between items-center mb-3">
                              <div>
                                <span className="text-lg font-bold text-aragon-blue">
                                  {formatPrice(player.price)}
                                </span>
                                <p className="text-xs text-gray-500">Precio pagado</p>
                              </div>
                              <div className="text-right">
                                <span className="text-sm font-medium text-green-600">
                                  {formatPrice(Math.floor(player.price * 0.8))}
                                </span>
                                <p className="text-xs text-gray-500">Precio venta</p>
                              </div>
                            </div>

                            <Button
                              onClick={() => sellPlayer(player.id)}
                              variant="outline"
                              className="w-full border-red-300 text-red-600 hover:bg-red-50"
                            >
                              Vender Jugador
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Acciones rápidas */}
        {user.players?.length > 0 && (
          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border-2 border-aragon-blue">
              <CardHeader>
                <CardTitle className="text-aragon-blue">⚽ Crear Alineación</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Con {user.players.length} jugadores fichados, ya puedes crear tu alineación ideal
                </p>
                <Link href="/alineacion">
                  <Button className="bg-aragon-blue hover:bg-blue-700">
                    Ir a Alineación
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="border-2 border-aragon-red">
              <CardHeader>
                <CardTitle className="text-aragon-red">🛒 Seguir Fichando</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Tienes {formatPrice(user.budget)} disponibles para más fichajes
                </p>
                <Link href="/mercado">
                  <Button className="bg-aragon-red hover:bg-red-700">
                    Volver al Mercado
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  )
}
