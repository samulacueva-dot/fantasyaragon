"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { useRouter } from "next/navigation"
import Image from "next/image"

// Datos de jugadores del Atlético Aragón
const playersData = [
  // Fútbol 11 - Porteros
  { id: 1, name: "Sergio Rambla", position: "POR", category: "Fútbol 11", price: 4500000, points: 120, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Diego" },

  // Fútbol 11 - Defensas
  { id: 3, name: "Raul Comin", position: "DEF", category: "Fútbol 11", price: 2500000, points: 180, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alvaro" },
  { id: 4, name: "Felipe Franco", position: "DEF", category: "Fútbol 11", price: 800000, points: 145, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Miguel" },
  { id: 5, name: "Mario Franco", position: "DEF", category: "Fútbol 11", price: 800000, points: 165, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Pablo" },
  { id: 6, name: "Marcos Gale", position: "DEF", category: "Fútbol 11", price: 6500000, points: 130, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sergio" },
  { id: 7, name: "Javier Rupérez", position: "DEF", category: "Fútbol 11", price: 1900000, points: 110, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Raul" },
  { id: 8, name: "Lucas Payero", position: "DEF", category: "Fútbol 11", price: 1100000, points: 110, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Raul" },
  { id: 9, name: "Juan Rodrigo", position: "DEF", category: "Fútbol 11", price: 1100000, points: 110, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Raul" },
  { id: 10, name: "Alejandro Carrizosa", position: "DEF", category: "Fútbol 11", price: 800000, points: 110, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Raul" },
  { id: 11, name: "Fernando Reguillo", position: "DEF", category: "Fútbol 11", price: 4050000, points: 110, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Raul" },

  // Fútbol 11 - Centrocampistas
  { id: 12, name: "Daniel Gutierrez", position: "MED", category: "Fútbol 11", price: 8200000, points: 220, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Antonio" },
  { id: 13, name: "Saul Chuse Irache", position: "MED", category: "Fútbol 11", price: 10800000, points: 195, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Javier" },
  { id: 14, name: "Pablo Carrey", position: "MED", category: "Fútbol 11", price: 3000000, points: 170, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Luis" },
  { id: 15, name: "Marcos Neva", position: "MED", category: "Fútbol 11", price: 5000000, points: 140, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=David" },
  { id: 16, name: "Roberto Pastor", position: "MED", category: "Fútbol 11", price: 9000000, points: 125, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Oscar" },

  // Fútbol 11 - Delanteros
  { id: 17, name: "Hector Nsue Ntutumu", position: "DEL", category: "Fútbol 11", price: 19500000, points: 285, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Roberto" },
  { id: 18, name: "Guzman Lopez", position: "DEL", category: "Fútbol 11", price: 16200000, points: 250, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Fernando" },
  { id: 19, name: "Samuel Lacueva", position: "DEL", category: "Fútbol 11", price: 15500000, points: 205, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Adrian" },
  { id: 20, name: "Diego Rupérez", position: "DEL", category: "Fútbol 11", price: 21800000, points: 165, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Manuel" },
  { id: 21, name: "Gabriel Galé", position: "DEL", category: "Fútbol 11", price: 18800000, points: 165, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Manuel" },
  { id: 22, name: "Alvaro Sangüesa", position: "DEL", category: "Fútbol 11", price: 20800000, points: 165, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Manuel" },

  // Fútbol Sala - Porteros
  { id: 23, name: "Iván Delgado", position: "POR", category: "Fútbol Sala", price: 7200000, points: 105, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Ivan" },
  { id: 24, name: "Jorge Medina", position: "POR", category: "Fútbol Sala", price: 5800000, points: 90, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Jorge" },

  // Fútbol Sala - Cierre
  { id: 25, name: "Francisco Navarro", position: "CIE", category: "Fútbol Sala", price: 11800000, points: 175, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Francisco" },
  { id: 26, name: "Alberto Ramos", position: "CIE", category: "Fútbol Sala", price: 9500000, points: 145, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alberto" },

  // Fútbol Sala - Ala
  { id: 27, name: "Daniel Guerrero", position: "ALA", category: "Fútbol Sala", price: 13200000, points: 190, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Daniel" },
  { id: 28, name: "Rubén Molina", position: "ALA", category: "Fútbol Sala", price: 10900000, points: 160, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Ruben" },
  { id: 29, name: "Alejandro Ortiz", position: "ALA", category: "Fútbol Sala", price: 8800000, points: 135, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alejandro" },

  // Fútbol Sala - Pívot
  { id: 30, name: "Cristian Herrera", position: "PIV", category: "Fútbol Sala", price: 16800000, points: 260, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Cristian" },
  { id: 31, name: "Jesús Blanco", position: "PIV", category: "Fútbol Sala", price: 14500000, points: 215, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Jesus" },
  { id: 32, name: "Mario Núñez", position: "PIV", category: "Fútbol Sala", price: 11200000, points: 170, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Mario" },

  // Entrenadores
  { id: 33, name: "Carlos Mendoza", position: "ENT", category: "Entrenador", price: 5000000, points: 80, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=CarlosMendoza" },
  { id: 34, name: "José Luis Martín", position: "ENT", category: "Entrenador", price: 6500000, points: 95, form: "excellent", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=JoseLuis" },

  // Nuevos jugadores añadidos - Fútbol 11
  { id: 35, name: "FERNANDO REGUILLO ESCOLANO", position: "DEF", category: "Fútbol 11", price: 9200000, points: 142, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Hector" },
  { id: 36, name: "JUAN RODRIGO ANDREO", position: "DEF", category: "Fútbol 11", price: 8800000, points: 135, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Victor" },
  { id: 37, name: "DIEGO RUPÉREZ ESTEBAN", position: "MED", category: "Fútbol 11", price: 12000000, points: 185, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Marcos" },
  { id: 38, name: "JAVIER RUPÉREZ ESTEBAN", position: "MED", category: "Fútbol 11", price: 11000000, points: 160, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Iker" },
  { id: 39, name: "MARIO SANCHEZ OLALLA", position: "DEL", category: "Fútbol 11", price: 14500000, points: 210, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Joel" },
  { id: 40, name: "ALVARO SANGÜESA PARDOS", position: "DEL", category: "Fútbol 11", price: 12800000, points: 190, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Borja" },

  { id: 41, name: "Raúl Soria", position: "POR", category: "Fútbol Sala", price: 6400000, points: 95, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Raul" },
  { id: 42, name: "Adrián Vela", position: "CIE", category: "Fútbol Sala", price: 9800000, points: 150, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Adrian" },
  { id: 43, name: "Nicolás Pardo", position: "ALA", category: "Fútbol Sala", price: 10200000, points: 155, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Nicolas" },
  { id: 44, name: "Santiago Ríos", position: "ALA", category: "Fútbol Sala", price: 9400000, points: 145, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Santiago" },
  { id: 45, name: "Toni Campos", position: "PIV", category: "Fútbol Sala", price: 13200000, points: 195, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Toni" },
  { id: 46, name: "Iván Serrano", position: "PIV", category: "Fútbol Sala", price: 11800000, points: 175, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=IvanSerrano" },

  { id: 47, name: "Sergi Castillo", position: "POR", category: "Fútbol 11", price: 6700000, points: 100, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sergi" },
  { id: 48, name: "Álex Muñoz", position: "POR", category: "Fútbol 11", price: 6100000, points: 88, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex" },

  { id: 49, name: "Miguel Ángel Rubio", position: "ENT", category: "Entrenador", price: 6000000, points: 90, form: "good", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=MiguelAngel" },
  { id: 50, name: "Raúl Pérez", position: "ENT", category: "Entrenador", price: 5500000, points: 85, form: "average", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=RaulPerez" }
]

export default function MercadoPage() {
  const [user, setUser] = useState<any>(null)
  const [players, setPlayers] = useState(playersData)
  const [filter, setFilter] = useState("all")
  const [search, setSearch] = useState("")
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("fantasyaragon_user")
    if (!userData) {
      router.push("/login")
      return
    }
    setUser(JSON.parse(userData))
  }, [router])

  const buyPlayer = (playerId: number) => {
    const player = players.find(p => p.id === playerId)
    if (!player || !user) return

    if (user.budget >= player.price) {
      const updatedUser = {
        ...user,
        budget: user.budget - player.price,
        players: [...user.players, player]
      }
      setUser(updatedUser)
      localStorage.setItem("fantasyaragon_user", JSON.stringify(updatedUser))

      // Remover jugador del mercado
      setPlayers(players.filter(p => p.id !== playerId))
    } else {
      alert("No tienes suficiente presupuesto para fichar a este jugador")
    }
  }

  const filteredPlayers = players.filter(player => {
    const matchesFilter = filter === "all" ||
                         filter === "futbol11" && player.category === "Fútbol 11" ||
                         filter === "futbolsala" && player.category === "Fútbol Sala" ||
                         filter === "entrenador" && player.category === "Entrenador"

    const matchesSearch = player.name.toLowerCase().includes(search.toLowerCase()) ||
                         player.position.toLowerCase().includes(search.toLowerCase())

    return matchesFilter && matchesSearch
  })

  const formatPrice = (price: number) => {
    return `${(price / 1000000).toFixed(1)}M€`
  }

  const getFormColor = (form: string) => {
    switch (form) {
      case "excellent": return "text-green-600 bg-green-50"
      case "good": return "text-blue-600 bg-blue-50"
      case "average": return "text-yellow-600 bg-yellow-50"
      default: return "text-gray-600 bg-gray-50"
    }
  }

  if (!user) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 mx-auto mb-4 bg-aragon-gradient rounded-full flex items-center justify-center">
          <span className="text-white font-bold text-xl">AA</span>
        </div>
        <p>Cargando...</p>
      </div>
    </div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-aragon-blue rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">FA</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">FantasyAragon</h1>
                  <p className="text-xs text-gray-600">Mercado de Jugadores</p>
                </div>
              </Link>
            </div>

            <nav className="hidden md:flex space-x-8">
              <Link href="/mercado" className="text-aragon-red font-medium">
                Mercado
              </Link>
              <Link href="/alineacion" className="text-gray-700 hover:text-aragon-red transition-colors">
                Alineación
              </Link>
              <Link href="/mi-equipo" className="text-gray-700 hover:text-aragon-red transition-colors">
                Mi Equipo
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-600">Presupuesto</p>
                <p className="font-bold text-aragon-blue">{formatPrice(user.budget)}</p>
              </div>
              <div className="w-10 h-10 bg-aragon-gradient rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">{user.email[0].toUpperCase()}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Mercado de Jugadores</h1>
          <p className="text-gray-600">Ficha a los mejores jugadores del Atlético Aragón para tu equipo fantasy</p>
        </div>

        {/* Filtros y búsqueda */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-wrap gap-4">
            <input
              type="text"
              placeholder="Buscar jugador..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-aragon-blue focus:border-transparent"
            />

            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-aragon-blue focus:border-transparent"
            >
              <option value="all">Todas las categorías</option>
              <option value="futbol11">Fútbol 11</option>
              <option value="futbolsala">Fútbol Sala</option>
              <option value="entrenador">Entrenadores</option>
            </select>
          </div>

          <div className="flex gap-2 text-sm">
            <span className="text-gray-600">Jugadores disponibles:</span>
            <span className="font-medium">{filteredPlayers.length}</span>
          </div>
        </div>

        {/* Lista de jugadores */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredPlayers.map((player) => (
            <Card key={player.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">{player.name}</CardTitle>
                    <p className="text-sm text-gray-600">{player.category}</p>
                  </div>
                  <div className="text-center">
                    <span className="inline-block px-2 py-1 text-xs font-medium bg-aragon-blue text-white rounded">
                      {player.position}
                    </span>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                {/* Player photo */}
                <div className="flex justify-center mb-3">
                  <Image
                    src={player.photo || "https://ugc.same-assets.com/ABC6Zv1oBiAnfTM412UcuRY4v5JUluX5.png"}
                    alt={player.name}
                    width={64}
                    height={64}
                    className="rounded-full border-2 border-aragon-blue bg-white"
                  />
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Puntos</span>
                    <span className="font-bold text-gray-900">{player.points}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Forma</span>
                    <span className={`px-2 py-1 text-xs font-medium rounded ${getFormColor(player.form)}`}>
                      {player.form === "excellent" ? "Excelente" :
                       player.form === "good" ? "Buena" : "Regular"}
                    </span>
                  </div>

                  {/* Category row */}
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Categoría</span>
                    <span className="px-2 py-1 text-xs font-medium rounded bg-gray-100 text-gray-800">
                      {player.category}
                    </span>
                  </div>

                  <div className="border-t pt-3">
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-lg font-bold text-aragon-red">
                        {formatPrice(player.price)}
                      </span>
                      <span className="text-xs text-gray-500">Precio</span>
                    </div>

                    <Button
                      onClick={() => buyPlayer(player.id)}
                      disabled={user.budget < player.price}
                      className="w-full bg-aragon-red hover:bg-red-700 disabled:bg-gray-300"
                    >
                      {user.budget >= player.price ? "Fichar" : "Sin presupuesto"}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredPlayers.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-200 rounded-full flex items-center justify-center">
              <span className="text-gray-500">🔍</span>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No se encontraron jugadores</h3>
            <p className="text-gray-600">Prueba a cambiar los filtros o la búsqueda</p>
          </div>
        )}
      </main>
    </div>
  )
}
