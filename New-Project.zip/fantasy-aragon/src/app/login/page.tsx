"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { useRouter } from "next/navigation"
import Image from "next/image"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    // Simular login - aquí conectarías con tu backend
    setTimeout(() => {
      // Por ahora, cualquier email/password funciona
      if (email && password) {
        const user = {
          email,
          id: Math.random().toString(36).substr(2, 9),
          budget: 75000000, // Usuario existente con menos presupuesto
          players: [],
          lineups: []
        }
        localStorage.setItem("fantasyaragon_user", JSON.stringify(user))
        router.push("/mercado")
      } else {
        setError("Credenciales incorrectas")
        setLoading(false)
      }
    }, 1000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header simplificado */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 rounded-full overflow-hidden">
                <Image
                  src="https://ugc.same-assets.com/XHdtQQD7bhbEkZuHE1kme6NIvCnn6fnK.png"
                  alt="Atlético Aragón Logo"
                  width={40}
                  height={40}
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">FantasyAragon</h1>
                <p className="text-xs text-gray-600">Atlético Aragón Fantasy</p>
              </div>
            </Link>

            <Link href="/register">
              <Button variant="outline" size="sm">
                Crear cuenta
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Formulario de login */}
      <main className="max-w-md mx-auto px-4 py-16">
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full overflow-hidden bg-white">
              <Image
                src="https://ugc.same-assets.com/zRvjHOwVPerEAPJrksGI2jEY9oi9SWta.png"
                alt="Atlético Aragón Logo"
                width={64}
                height={64}
                className="w-full h-full object-contain p-1"
              />
            </div>
            <CardTitle className="text-2xl text-gray-900">Bienvenido de vuelta</CardTitle>
            <p className="text-gray-600 mt-2">
              Inicia sesión para gestionar tu equipo del Atlético Aragón
            </p>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Correo electrónico
                </label>
                <input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-aragon-blue focus:border-transparent"
                  placeholder="tu@email.com"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  Contraseña
                </label>
                <input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-aragon-blue focus:border-transparent"
                  placeholder="Tu contraseña"
                />
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md text-sm">
                  {error}
                </div>
              )}

              <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-md text-sm">
                <p className="font-medium">💡 Consejo:</p>
                <p>Puedes usar cualquier email y contraseña para probar la demo</p>
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-aragon-red hover:bg-red-700 text-white py-2 h-11"
              >
                {loading ? "Iniciando sesión..." : "Iniciar sesión"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                ¿No tienes una cuenta?{" "}
                <Link href="/register" className="text-aragon-blue hover:text-blue-700 font-medium">
                  Regístrate gratis
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 text-center text-sm text-gray-500">
          <p>¿Olvidaste tu contraseña? Contáctanos para recuperarla</p>
        </div>
      </main>
    </div>
  )
}
